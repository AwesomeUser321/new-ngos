<?php

namespace App\Http\Controllers;

use App\Models\AimObjective;
use App\Models\BasicInformation;
use Illuminate\Http\Request;

class BasicInformationController extends Controller
{
    public function store(Request $request)
{
    $data = $request->validate([
        'name' => 'required|string',
        'contact' => 'required|string',
        'address' => 'required|string',
        'constitution_file' => 'nullable|file|mimes:pdf,doc,docx|max:2048',
        'aims' => 'required|array',
        
    ]);

    // dd($data);

    // Upload the constitution file
    if ($request->hasFile('constitution_file')) {
        $data['constitution_file'] = $request->file('constitution_file')->store('constitutions', 'public');
    }

    $basicInfo = BasicInformation::create($data);

    // Attach multiple aims
    $basicInfo->aims()->attach($data['aims']);

    return response()->json([
        'message' => 'Basic Information created successfully',
        'data' => $basicInfo->load('aims'),
    ], 201);
}

public function index()
    {
        // Fetch all aims
        $aims = AimObjective::all();

        // Return the data as JSON
        return response()->json([
            'message' => 'Aim Objectives retrieved successfully',
            'data' => $aims,
        ]);
    }

}
