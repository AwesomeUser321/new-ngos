<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BasicsAim extends Model
{
    protected $fillable = ['basic_info_id', 'aim_obj_id'];
}
